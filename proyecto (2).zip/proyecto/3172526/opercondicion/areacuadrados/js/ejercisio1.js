/*
ejrcisio 1
Kevin mora
20 de 09 2025
*/
//declaración de variables
let noteOne=20;
let noteTwo=30;
let noteThree=48;
let average;
//proceso 
average = (noteOne + noteTwo + noteThree ) / 3;
//imprimir
console.log("the average is: " +average);
