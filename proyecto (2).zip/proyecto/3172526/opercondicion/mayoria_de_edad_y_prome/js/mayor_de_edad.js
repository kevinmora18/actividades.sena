/*
kevin mora 
23 09 2025
ejercisio 2
*/
let ageOne=11;
let ageTwo=18;
let ageThree=17;
let average;

average = (ageOne + ageTwo + ageThree)/3

console.log("edad1:"+ageOne);
if(ageOne >= 18){
console.log('si es mayor de edad')}
else{
console.log('no es mayor de edad')
}
console.log("edad2:"+ageTwo);

if(ageTwo >= 18){
console.log('si es mayor de edad')}
else{
console.log('no es mayor de edad')
}
console.log("edad3:"+ageThree);

if(ageThree >= 18){
console.log('si es mayor de edad')}
else{
console.log('no es mayor de edad')
}
 
if(average >=18){
console.log('la mayoria del grupo son mayor de edad')}
else{
console.log('la mayoria del grupo son menores de edad')}

